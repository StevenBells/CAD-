﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocAction.h"
#include "AcDbAssocGlobal.h"
#include "dbeval.h"
#include "AcValue.h"

#ifndef AcDbAssocAction
#define AcDbAssocAction GcDbAssocAction
#endif

#ifndef AcDbImpAssocAction
#define AcDbImpAssocAction GcDbImpAssocAction
#endif
