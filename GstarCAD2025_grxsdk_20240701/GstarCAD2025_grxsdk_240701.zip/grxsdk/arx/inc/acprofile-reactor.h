﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcprofile-reactor.h"
#include "AdAChar.h"
#ifndef AcApProfileManagerReactor
#define AcApProfileManagerReactor GcApProfileManagerReactor
#endif

