﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocNetwork.h"
#include "AcString.h"
#include "AcDbAssocAction.h"
#ifndef AcDbAssocNetwork
#define AcDbAssocNetwork GcDbAssocNetwork
#endif

#ifndef AcDbAssocNetworkIterator
#define AcDbAssocNetworkIterator GcDbAssocNetworkIterator
#endif
