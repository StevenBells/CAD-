﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocArrayItem.h"

#ifndef AcDbItemLocator
#define AcDbItemLocator GcDbItemLocator
#endif

#ifndef AcDbAssocArrayItem
#define AcDbAssocArrayItem GcDbAssocArrayItem
#endif

#ifndef AcDbImpAssocArrayItem
#define AcDbImpAssocArrayItem GcDbImpAssocArrayItem
#endif
