﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "dbmain.h"
#include "AdAChar.h"
#include "../../inc/dbltrans.h"

#ifndef AcDbLongTransWorkSetIterator
#define AcDbLongTransWorkSetIterator GcDbLongTransWorkSetIterator
#endif

#ifndef AcDbLongTransaction
#define AcDbLongTransaction GcDbLongTransaction
#endif

