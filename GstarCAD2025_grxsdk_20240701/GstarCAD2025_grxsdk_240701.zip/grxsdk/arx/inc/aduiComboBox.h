﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiComboBox.h"

#ifndef CAdUiComboBox
#define CAdUiComboBox CGdUiComboBox
#endif

#ifndef CAdUiComboBoxDraw
#define CAdUiComboBoxDraw CGdUiComboBoxDraw
#endif

