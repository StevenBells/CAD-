﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcuiButton.h"
#ifndef CAcUiOwnerDrawButton
#define CAcUiOwnerDrawButton CGcUiOwnerDrawButton
#endif

#ifndef CAcUiBitmapButton
#define CAcUiBitmapButton CGcUiBitmapButton
#endif

#ifndef CAcUiBitmapStatic
#define CAcUiBitmapStatic CGcUiBitmapStatic
#endif

#ifndef CAcUiDropSite
#define CAcUiDropSite CGcUiDropSite
#endif

#ifndef CAcUiPickButton
#define CAcUiPickButton CGcUiPickButton
#endif

#ifndef CAcUiSelectButton
#define CAcUiSelectButton CGcUiSelectButton
#endif

#ifndef CAcUiQuickSelectButton
#define CAcUiQuickSelectButton CGcUiQuickSelectButton
#endif

#ifndef CAcUiToolButton
#define CAcUiToolButton CGcUiToolButton
#endif

