﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocExtendSurfaceActionBody.h"
#include "AcDbAssocPathBasedSurfaceActionBody.h"

#ifndef AcDbSurface
#define AcDbSurface GcDbSurface
#endif

#ifndef AcDbAssocExtendSurfaceActionBody
#define AcDbAssocExtendSurfaceActionBody GcDbAssocExtendSurfaceActionBody
#endif

