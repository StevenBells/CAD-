﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlPlotConfig.h"
#include "AcPl.h"
#include "acarray.h"
#include "gepnt2d.h"
#include "geblok2d.h"
#include "dblayout.h"

#ifndef AcPlPlotConfig
#define AcPlPlotConfig GcPlPlotConfig
#endif

