﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbdimptref.h"

#ifndef AcDbFullSubentPathArray
#define AcDbFullSubentPathArray GcDbFullSubentPathArray
#endif

#ifndef AcDbHandleArrayPtRef
#define AcDbHandleArrayPtRef GcDbHandleArrayPtRef
#endif

#ifndef AcDbPointRef
#define AcDbPointRef GcDbPointRef
#endif

#ifndef AcDbOsnapPointRef
#define AcDbOsnapPointRef GcDbOsnapPointRef
#endif
