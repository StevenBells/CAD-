﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbboiler.h"
#include "rxboiler.h"

#ifndef ACDB_DECLARE_MEMBERS
#define ACDB_DECLARE_MEMBERS GCDB_DECLARE_MEMBERS
#endif

#ifndef ACDB_DECLARE_MEMBERS_EXPIMP
#define ACDB_DECLARE_MEMBERS_EXPIMP GCDB_DECLARE_MEMBERS_EXPIMP
#endif

#ifndef ACDBCORE2D_DECLARE_MEMBERS
#define ACDBCORE2D_DECLARE_MEMBERS GCDBCORE2D_DECLARE_MEMBERS
#endif
