﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcestext.h"
#include "acdb.h"
#include "AdAChar.h"
#include "AcDbCore2dDefs.h"


#ifndef acadErrorStatusText
#define acadErrorStatusText gcadErrorStatusText
#endif

