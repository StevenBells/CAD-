﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dynprops-GcFilterablePropertyContext.h"

#ifndef AcFilterablePropertyContext
#define AcFilterablePropertyContext GcFilterablePropertyContext
#endif

#ifndef acQuickPropertiesContext
#define acQuickPropertiesContext gcQuickPropertiesContext
#endif

#ifndef acTooltipContext
#define acTooltipContext gcTooltipContext
#endif
