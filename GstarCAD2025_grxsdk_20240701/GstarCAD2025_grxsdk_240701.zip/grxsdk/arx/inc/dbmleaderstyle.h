﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbmleaderstyle.h"
#include "AcString.h"
#include "dbmain.h"

#ifndef AcDbMLeaderStyle
#define AcDbMLeaderStyle GcDbMLeaderStyle
#endif

