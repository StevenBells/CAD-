﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcuiDialog.h"
#ifndef CAcUiDialog
#define CAcUiDialog CGcUiDialog
#endif

#ifndef CAcUiDialogBar
#define CAcUiDialogBar CGcUiDialogBar
#endif

#ifndef CAcUiFileDialog
#define CAcUiFileDialog CGcUiFileDialog
#endif

#ifndef CAcUiTabChildDialog
#define CAcUiTabChildDialog CGcUiTabChildDialog
#endif

#ifndef CAcUiTabMainDialog
#define CAcUiTabMainDialog CGcUiTabMainDialog
#endif

