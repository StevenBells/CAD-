﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiFileDialog.h"

#ifndef CAdUiFileDialog
#define CAdUiFileDialog CGdUiFileDialog
#endif

#ifndef DoAdUiMessage
#define DoAdUiMessage DoGdUiMessage
#endif

#ifndef OnAdUiMessage
#define OnAdUiMessage OnGdUiMessage
#endif

