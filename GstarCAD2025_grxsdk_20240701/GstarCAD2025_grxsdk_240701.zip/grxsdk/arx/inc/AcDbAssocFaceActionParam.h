﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocFaceActionParam.h"
#include "AcDbAssocActionParam.h"
#include "AcDbGeomRef.h"
#ifndef AcDbAssocFaceActionParam
#define AcDbAssocFaceActionParam GcDbAssocFaceActionParam
#endif
