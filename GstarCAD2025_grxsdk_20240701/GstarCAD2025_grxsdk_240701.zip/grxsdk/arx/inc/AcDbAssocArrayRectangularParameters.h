﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocArrayRectangularParameters.h"
#include "AcDbAssocArrayCommonParameters.h"

#ifndef AcDbAssocArrayRectangularParameters
#define AcDbAssocArrayRectangularParameters GcDbAssocArrayRectangularParameters
#endif

#ifndef AcDbImpAssocArrayRectangularParameters
#define AcDbImpAssocArrayRectangularParameters GcDbImpAssocArrayRectangularParameters
#endif
