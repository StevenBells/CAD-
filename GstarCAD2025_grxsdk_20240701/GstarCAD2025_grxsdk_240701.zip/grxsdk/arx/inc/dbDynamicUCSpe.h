﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbDynamicUCSpe.h"
#include "acdb.h"
#include "dbmain.h"

#ifndef AcDbDynamicUCSPE
#define AcDbDynamicUCSPE GcDbDynamicUCSPE
#endif

#ifndef AcDbNonSubEntDynamicUCSPE
#define AcDbNonSubEntDynamicUCSPE GcDbNonSubEntDynamicUCSPE
#endif
