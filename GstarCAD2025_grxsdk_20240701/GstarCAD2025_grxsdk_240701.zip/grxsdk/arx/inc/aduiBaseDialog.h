﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiBaseDialog.h"

#ifndef CAdUiBaseDialog
#define CAdUiBaseDialog CGdUiBaseDialog
#endif

#ifndef OnAdUiTimer
#define OnAdUiTimer OnGdUiTimer
#endif

