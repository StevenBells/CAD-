﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcFdUiFieldFormatDialog.h"
#include "AcFdUiFormatDialog.h"
#ifndef CAcFdUiFieldFormatDialog
#define CAcFdUiFieldFormatDialog CGcFdUiFieldFormatDialog
#endif

