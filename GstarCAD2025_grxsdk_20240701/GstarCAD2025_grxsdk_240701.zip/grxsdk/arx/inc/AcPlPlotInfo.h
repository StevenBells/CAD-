﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlPlotInfo.h"
#include "AcPlObject.h"

#ifndef AcPlPlotInfo
#define AcPlPlotInfo GcPlPlotInfo
#endif


#ifndef AcPlPlotConfig
#define AcPlPlotConfig GcPlPlotConfig
#endif

#ifndef AcRxObject
#define AcRxObject GcRxObject
#endif

#ifndef AcDbPlotSettings
#define AcDbPlotSettings GcDbPlotSettings
#endif

#ifndef AcString
#define AcString GcString
#endif

