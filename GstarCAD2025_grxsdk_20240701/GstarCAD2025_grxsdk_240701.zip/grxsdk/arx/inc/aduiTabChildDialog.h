﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiTabChildDialog.h"

#ifndef CAdUiTabChildDialog
#define CAdUiTabChildDialog CGdUiTabChildDialog
#endif

#ifndef GetAcadTabPointer
#define GetAcadTabPointer GetGcadTabPointer
#endif

#ifndef SetAcadTabChildFocus
#define SetAcadTabChildFocus SetGcadTabChildFocus
#endif
