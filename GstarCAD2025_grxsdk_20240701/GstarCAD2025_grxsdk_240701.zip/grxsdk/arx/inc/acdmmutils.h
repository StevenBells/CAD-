﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcdmmutils.h"
#include "acarray.h"
#ifndef AcDMMWideString
#define AcDMMWideString GcDMMWideString
#endif

#ifndef AcDMMStringVec
#define AcDMMStringVec GcDMMStringVec
#endif

#ifndef AcDMMNode
#define AcDMMNode GcDMMNode
#endif

#ifndef AcDMMResourceInfo
#define AcDMMResourceInfo GcDMMResourceInfo
#endif
