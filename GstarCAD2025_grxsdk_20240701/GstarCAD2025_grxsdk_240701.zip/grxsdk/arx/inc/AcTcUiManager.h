﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcTcUiManager.h"
#include "AcTcUiToolPaletteSet.h"
#include "AcTcUI.h"

#ifndef CAcTcUiManager
#define CAcTcUiManager CGcTcUiManager
#endif

#ifndef AcTcUiSystemInternals
#define AcTcUiSystemInternals GcTcUiSystemInternals
#endif

