﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocVertexActionParam.h"
#include "AcDbAssocEdgeActionParam.h"
#include "AcDbGeomRef.h"
#ifndef AcDbAssocVertexActionParam
#define AcDbAssocVertexActionParam GcDbAssocVertexActionParam
#endif
