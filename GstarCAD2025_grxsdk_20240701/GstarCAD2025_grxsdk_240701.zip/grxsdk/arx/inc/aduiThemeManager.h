﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiThemeManager.h"

#ifndef CAdUiThemeMgrReactor
#define CAdUiThemeMgrReactor CGdUiThemeMgrReactor
#endif

#ifndef CAdUiThemeManager
#define CAdUiThemeManager CGdUiThemeManager
#endif

