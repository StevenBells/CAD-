﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GdCharFmt.h"
#include "adesk.h"
#include "acbasedefs.h"
#ifndef AdCharFormatter
#define AdCharFormatter GdCharFormatter
#endif

#ifndef AdCharFmt_Assert
#define AdCharFmt_Assert GdCharFmt_Assert
#endif

