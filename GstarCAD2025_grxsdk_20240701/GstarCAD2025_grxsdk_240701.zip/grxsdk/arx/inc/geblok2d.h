﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/geblok2d.h"
#include "geent2d.h"

#ifndef AcGePoint2d
#define AcGePoint2d GcGePoint2d
#endif

#ifndef AcGeVector2d
#define AcGeVector2d GcGeVector2d
#endif

#ifndef AcGeBoundBlock2d
#define AcGeBoundBlock2d GcGeBoundBlock2d
#endif

