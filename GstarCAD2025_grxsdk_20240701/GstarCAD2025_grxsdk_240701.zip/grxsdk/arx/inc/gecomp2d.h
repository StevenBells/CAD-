﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gecomp2d.h"
#include "gecurv2d.h"
#include "gevptar.h"
#include "geintarr.h"

#ifndef AcGeCompositeCurve2d
#define AcGeCompositeCurve2d GcGeCompositeCurve2d
#endif
