﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbdictdflt.h"
#include "dbdict.h"

#ifndef AcDbDictionaryWithDefault
#define AcDbDictionaryWithDefault GcDbDictionaryWithDefault
#endif

#ifndef AcDbImpDictionaryWithDefault
#define AcDbImpDictionaryWithDefault GcDbImpDictionaryWithDefault
#endif
