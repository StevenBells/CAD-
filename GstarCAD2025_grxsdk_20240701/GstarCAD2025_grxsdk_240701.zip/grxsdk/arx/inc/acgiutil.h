﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcgiutil.h"
#include "dbid.h"
#include "AdAChar.h"
#include "acgi.h"

#ifndef fromAcDbTextStyle
#define fromAcDbTextStyle fromGcDbTextStyle
#endif

#ifndef toAcDbTextStyle
#define toAcDbTextStyle toGcDbTextStyle
#endif
