﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gecomp3d.h"
#include "gecurv3d.h"
#include "gevptar.h"
#include "geintarr.h"

#ifndef AcGeCompositeCurve3d
#define AcGeCompositeCurve3d GcGeCompositeCurve3d
#endif

