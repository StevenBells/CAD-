﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocEdgeActionParam.h"
#include "AcDbAssocActionParam.h"
#include "AcDbGeomRef.h"

#ifndef AcDbAssocEdgeActionParam
#define AcDbAssocEdgeActionParam GcDbAssocEdgeActionParam
#endif
