﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbmline.h"
#include "dbmain.h"

#ifndef AcDbMline
#define AcDbMline GcDbMline
#endif

#ifndef AcGePlane
#define AcGePlane GcGePlane
#endif

