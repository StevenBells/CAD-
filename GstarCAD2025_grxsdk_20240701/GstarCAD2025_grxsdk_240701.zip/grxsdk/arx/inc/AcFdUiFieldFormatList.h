﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcFdUiFieldFormatList.h"
#include "AcFdUiFormatList.h"

#ifndef CAcFdUiFieldFormatList
#define CAcFdUiFieldFormatList CGcFdUiFieldFormatList
#endif

