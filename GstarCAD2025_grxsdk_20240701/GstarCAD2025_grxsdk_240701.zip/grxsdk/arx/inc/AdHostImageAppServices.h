﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GdHostImageAppServices.h"
#include "AdAChar.h"
#include "adesk.h"

#ifndef Atil
#define Atil Gtil
#endif

#ifndef AdHostImageAppServices
#define AdHostImageAppServices GdHostImageAppServices
#endif

#ifndef getAdHostImageAppServices
#define getAdHostImageAppServices getGdHostImageAppServices
#endif
