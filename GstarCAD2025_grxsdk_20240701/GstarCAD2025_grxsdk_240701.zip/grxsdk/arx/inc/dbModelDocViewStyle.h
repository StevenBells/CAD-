﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbModelDocViewStyle.h"
#include "acdbport.h"
#include "dbmain.h"
#include "dbmtext.h"
#include "AcString.h"

#ifndef AcDbModelDocViewStyle
#define AcDbModelDocViewStyle GcDbModelDocViewStyle
#endif

#ifndef AcDbImpModelDocViewStyle
#define AcDbImpModelDocViewStyle GcDbImpModelDocViewStyle
#endif

