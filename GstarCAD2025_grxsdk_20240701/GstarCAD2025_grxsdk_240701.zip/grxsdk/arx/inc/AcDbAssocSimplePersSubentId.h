﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocSimplePersSubentId.h"
#include "acarray.h"
#include "AcDbAssocPersSubentId.h"
#ifndef AcDbAssocSimplePersSubentId
#define AcDbAssocSimplePersSubentId GcDbAssocSimplePersSubentId
#endif
