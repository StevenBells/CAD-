﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GsdkPromptBase.h"
#include "dbjig.h"
#include "adscodes.h"

#ifndef acedSetIUnknownForCurrentCommand
#define acedSetIUnknownForCurrentCommand gcedSetIUnknownForCurrentCommand
#endif

#ifndef AsdkPromptBase
#define AsdkPromptBase GsdkPromptBase
#endif

#ifndef IDR_ASDKPROMPTBASE
#define IDR_ASDKPROMPTBASE IDR_GSDKPROMPTBASE
#endif

#ifndef IAcadBaseObject2
#define IAcadBaseObject2 IGcadBaseObject2
#endif
