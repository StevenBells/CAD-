﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiToolBarCtrl.h"

#ifndef CAdUiToolBarCtrl
#define CAdUiToolBarCtrl CGdUiToolBarCtrl
#endif

#ifndef ADUI_TBSTYLE_AUTOSTRETCH
#define ADUI_TBSTYLE_AUTOSTRETCH GDUI_TBSTYLE_AUTOSTRETCH
#endif

