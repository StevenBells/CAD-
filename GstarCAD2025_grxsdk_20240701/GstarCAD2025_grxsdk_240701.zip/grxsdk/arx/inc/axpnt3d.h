﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gxpnt3d.h"
#include "gept3dar.h"
#include "gepnt3d.h"
#include "gevec3d.h"

#ifndef AcAxPoint3d
#define AcAxPoint3d GcAxPoint3d
#endif

#ifndef AcAxPoint3dArray
#define AcAxPoint3dArray GcAxPoint3dArray
#endif
