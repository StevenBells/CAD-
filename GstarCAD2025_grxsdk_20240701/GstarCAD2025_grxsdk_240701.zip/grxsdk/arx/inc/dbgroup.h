﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbgroup.h"
#include "dbmain.h"
#include "dbapserv.h"

#ifndef AcDbGroup
#define AcDbGroup GcDbGroup
#endif

#ifndef AcDbGroupIterator
#define AcDbGroupIterator GcDbGroupIterator
#endif
