﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "dbsurf.h"
#include "db3dProfile.h"
#include "../../inc/dbloftedsurf.h"

#ifndef AcDbLoftedSurface
#define AcDbLoftedSurface GcDbLoftedSurface
#endif

