﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocEdgeFilletActionBody.h"
#include "AcDbAssocPathBasedSurfaceActionBody.h"

#ifndef AcDbAssocEdgeFilletActionBody
#define AcDbAssocEdgeFilletActionBody GcDbAssocEdgeFilletActionBody
#endif
