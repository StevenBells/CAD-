﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcappvar.h"
#include "acdb.h"
#include "acadstrc.h"   

#ifndef AcDbAppSystemVariables
#define AcDbAppSystemVariables GcDbAppSystemVariables
#endif
