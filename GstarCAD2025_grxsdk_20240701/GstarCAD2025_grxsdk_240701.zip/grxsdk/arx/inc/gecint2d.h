﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gecint2d.h"
#include "adesk.h"
#include "gegbl.h"
#include "geent2d.h"
#include "geponc2d.h"
#include "geintrvl.h"

#ifndef AcGeCurve2d
#define AcGeCurve2d GcGeCurve2d
#endif

#ifndef AcGeCurveCurveInt2d
#define AcGeCurveCurveInt2d GcGeCurveCurveInt2d
#endif

