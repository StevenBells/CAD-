﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbCompoundObjectId.h"
#include "AcDbCore2dDefs.h"
#ifndef AcDbCompoundObjectId
#define AcDbCompoundObjectId GcDbCompoundObjectId
#endif

#ifndef AcDbParentTransformOfChildPE
#define AcDbParentTransformOfChildPE GcDbParentTransformOfChildPE
#endif
