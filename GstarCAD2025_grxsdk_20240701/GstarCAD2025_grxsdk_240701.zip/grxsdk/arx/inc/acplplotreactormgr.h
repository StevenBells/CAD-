﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcplplotreactormgr.h"
#include "AcPl.h"
#ifndef AcPlPlotReactorMgr
#define AcPlPlotReactorMgr GcPlPlotReactorMgr
#endif

#ifndef acplPlotReactorMgrPtr
#define acplPlotReactorMgrPtr gcplPlotReactorMgrPtr
#endif

#ifndef acplPlotReactorMgr
#define acplPlotReactorMgr gcplPlotReactorMgr
#endif

