﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcdb.h"
#include "adesk.h"
#include "AdAChar.h"   

#ifndef ACDB_MODEL_SPACE
#define ACDB_MODEL_SPACE GCDB_MODEL_SPACE
#endif
               
#ifndef ACDB_PAPER_SPACE
#define ACDB_PAPER_SPACE GCDB_PAPER_SPACE
#endif
               
#ifndef ACDB_NULL_HANDLE
#define ACDB_NULL_HANDLE GCDB_NULL_HANDLE
#endif

#ifndef ACDB_OPEN_BRACE_STR
#define ACDB_OPEN_BRACE_STR GCDB_OPEN_BRACE_STR
#endif
            
#ifndef ACDB_OPEN_BRACE_CHAR
#define ACDB_OPEN_BRACE_CHAR GCDB_OPEN_BRACE_CHAR
#endif
           
#ifndef ACDB_CLOSE_BRACE_STR
#define ACDB_CLOSE_BRACE_STR GCDB_CLOSE_BRACE_STR
#endif
           
#ifndef ACDB_CLOSE_BRACE_CHAR
#define ACDB_CLOSE_BRACE_CHAR GCDB_CLOSE_BRACE_CHAR
#endif
          
#ifndef ACDB_GROUP_DICTIONARY
#define ACDB_GROUP_DICTIONARY GCDB_GROUP_DICTIONARY
#endif
          
#ifndef ACDB_MLINESTYLE_DICTIONARY
#define ACDB_MLINESTYLE_DICTIONARY GCDB_MLINESTYLE_DICTIONARY
#endif
     
#ifndef ACDB_LAYOUT_DICTIONARY
#define ACDB_LAYOUT_DICTIONARY GCDB_LAYOUT_DICTIONARY
#endif
         
#ifndef ACDB_PLOTSETTINGS_DICTIONARY
#define ACDB_PLOTSETTINGS_DICTIONARY GCDB_PLOTSETTINGS_DICTIONARY
#endif
   
#ifndef ACDB_PLOTSTYLENAME_DICTIONARY
#define ACDB_PLOTSTYLENAME_DICTIONARY GCDB_PLOTSTYLENAME_DICTIONARY
#endif
  
#ifndef ACDB_MATERIAL_DICTIONARY
#define ACDB_MATERIAL_DICTIONARY GCDB_MATERIAL_DICTIONARY
#endif
       
#ifndef ACDB_VISUALSTYLE_DICTIONARY
#define ACDB_VISUALSTYLE_DICTIONARY GCDB_VISUALSTYLE_DICTIONARY
#endif
    
#ifndef ACDB_COLOR_DICTIONARY
#define ACDB_COLOR_DICTIONARY GCDB_COLOR_DICTIONARY
#endif
          
#ifndef ACDB_TABLESTYLE_DICTIONARY
#define ACDB_TABLESTYLE_DICTIONARY GCDB_TABLESTYLE_DICTIONARY
#endif
     
#ifndef ACDB_EMBEDDED_OBJECT_STR
#define ACDB_EMBEDDED_OBJECT_STR GCDB_EMBEDDED_OBJECT_STR
#endif
       
#ifndef ACDB_LAYERSTATES_DICTIONARY
#define ACDB_LAYERSTATES_DICTIONARY GCDB_LAYERSTATES_DICTIONARY
#endif
    
#ifndef ACDB_FIELD_DICTIONARY
#define ACDB_FIELD_DICTIONARY GCDB_FIELD_DICTIONARY
#endif
          
#ifndef ACDB_FIELDLIST
#define ACDB_FIELDLIST GCDB_FIELDLIST
#endif
                 
#ifndef ACDB_ENHANCED_BLOCK
#define ACDB_ENHANCED_BLOCK GCDB_ENHANCED_BLOCK
#endif
            
#ifndef ACDB_ENHANCED_BLOCK_EVALKEY
#define ACDB_ENHANCED_BLOCK_EVALKEY GCDB_ENHANCED_BLOCK_EVALKEY
#endif
    
#ifndef ACDB_ENHANCED_BLOCK_REF
#define ACDB_ENHANCED_BLOCK_REF GCDB_ENHANCED_BLOCK_REF
#endif
        
#ifndef ACDB_SECTION_MANAGER
#define ACDB_SECTION_MANAGER GCDB_SECTION_MANAGER
#endif
           
#ifndef ACDB_DATALINK
#define ACDB_DATALINK GCDB_DATALINK
#endif
                  
#ifndef ACDB_MLEADERSTYLE_DICTIONARY
#define ACDB_MLEADERSTYLE_DICTIONARY GCDB_MLEADERSTYLE_DICTIONARY
#endif
   
#ifndef ACDB_ASSOCNETWORK_DICTIONARY
#define ACDB_ASSOCNETWORK_DICTIONARY GCDB_ASSOCNETWORK_DICTIONARY
#endif
   
#ifndef ACDB_SECTIONSTYLE_DICTIONARY
#define ACDB_SECTIONSTYLE_DICTIONARY GCDB_SECTIONSTYLE_DICTIONARY
#endif
   
#ifndef ACDB_DETAILSTYLE_DICTIONARY
#define ACDB_DETAILSTYLE_DICTIONARY GCDB_DETAILSTYLE_DICTIONARY
#endif
    
#ifndef ACDB_ANNOTATIONSCALES_COLLECTION
#define ACDB_ANNOTATIONSCALES_COLLECTION GCDB_ANNOTATIONSCALES_COLLECTION
#endif
 

#ifndef AcDb
#define AcDb GcDb
#endif

#ifndef AcDbDwgVersion
#define AcDbDwgVersion GcDbDwgVersion
#endif

#ifndef kDHL_AC1_2
#define kDHL_AC1_2 kDHL_GC1_2
#endif

#ifndef kDHL_AC1_40
#define kDHL_AC1_40 kDHL_GC1_40
#endif

#ifndef kDHL_AC1_50
#define kDHL_AC1_50 kDHL_GC1_50
#endif

#ifndef kDHL_AC2_20
#define kDHL_AC2_20 kDHL_GC2_20
#endif

#ifndef kDHL_AC2_10
#define kDHL_AC2_10 kDHL_GC2_10
#endif

#ifndef kDHL_AC2_21
#define kDHL_AC2_21 kDHL_GC2_21
#endif

#ifndef kDHL_AC2_22
#define kDHL_AC2_22 kDHL_GC2_22
#endif
