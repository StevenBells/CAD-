﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcApWindow.h"
#include "IAdHostWindow.h"

#ifndef AcApWindow
#define AcApWindow GcApWindow
#endif


#ifndef AcApWindowImp
#define AcApWindowImp GcApWindowImp
#endif
