﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocDependencyPE.h"
#include "AcDbCompoundObjectId.h"
#include "AcDbAssocGlobal.h"

#ifndef AcDbAssocDependencyPE
#define AcDbAssocDependencyPE GcDbAssocDependencyPE
#endif
