﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocSingleEdgePersSubentId.h"
#include "acarray.h"
#include "AcDbAssocPersSubentId.h"
#ifndef AcDbAssocSingleEdgePersSubentId
#define AcDbAssocSingleEdgePersSubentId GcDbAssocSingleEdgePersSubentId
#endif
