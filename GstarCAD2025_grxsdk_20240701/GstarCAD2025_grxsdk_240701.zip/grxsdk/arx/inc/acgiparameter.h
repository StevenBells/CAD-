﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcgiparameter.h"
#include "rxcopyonwriteobject.h"

#ifndef AcGiParameter
#define AcGiParameter GcGiParameter
#endif

#ifndef AcGiParameterImp
#define AcGiParameterImp GcGiParameterImp
#endif

