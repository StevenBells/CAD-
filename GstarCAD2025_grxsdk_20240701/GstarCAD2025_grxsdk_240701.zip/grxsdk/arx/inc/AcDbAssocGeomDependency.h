﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocGeomDependency.h"
#include "AcDbAssocDependency.h"
#include "AcDbAssocPersSubentId.h"
#ifndef AcDbAssocGeomDependency
#define AcDbAssocGeomDependency GcDbAssocGeomDependency
#endif
