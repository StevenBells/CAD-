﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gced-hatch.h"
#ifndef AcHatchNotifier
#define AcHatchNotifier GcHatchNotifier
#endif

#ifndef AcHatchEdReact
#define AcHatchEdReact GcHatchEdReact
#endif
