﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocTrimSurfaceActionBody.h"
#include "AcDbSurfaceTrimInfo.h"
#include "AcDbAssocPathBasedSurfaceActionBody.h"
#ifndef AcDbAssocTrimSurfaceActionBody
#define AcDbAssocTrimSurfaceActionBody GcDbAssocTrimSurfaceActionBody
#endif
