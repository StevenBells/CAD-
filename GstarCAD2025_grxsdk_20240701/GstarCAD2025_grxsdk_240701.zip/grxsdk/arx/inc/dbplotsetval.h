﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbplotsetval.h"
#include "AdAChar.h"

#ifndef AcDbPlotSettingsValidator
#define AcDbPlotSettingsValidator GcDbPlotSettingsValidator
#endif

