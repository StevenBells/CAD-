﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiRegistryAccess.h"

#ifndef CAdUiRegistryAccess
#define CAdUiRegistryAccess CGdUiRegistryAccess
#endif
 
#ifndef CAdUiRegistryWriteAccess
#define CAdUiRegistryWriteAccess CGdUiRegistryWriteAccess
#endif

#ifndef CAdUiRegistryDeleteAccess
#define CAdUiRegistryDeleteAccess CGdUiRegistryDeleteAccess
#endif
