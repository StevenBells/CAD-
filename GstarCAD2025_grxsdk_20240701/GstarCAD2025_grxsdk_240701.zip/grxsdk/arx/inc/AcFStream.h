﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcFStream.h"
#ifndef AcFStream_Assert
#define AcFStream_Assert GcFStream_Assert
#endif

#ifndef AcIfstream
#define AcIfstream GcIfstream
#endif

#ifndef AcOfstream
#define AcOfstream GcOfstream
#endif

#ifndef AcFStream_curLocale
#define AcFStream_curLocale GcFStream_curLocale
#endif

