﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiListBox.h"

#ifndef CAdUiListBox
#define CAdUiListBox CGdUiListBox
#endif

#ifndef OnAdUiMessage
#define OnAdUiMessage OnGdUiMessage
#endif

#ifndef GetAdUiParent
#define GetAdUiParent GetGdUiParent
#endif

#ifndef SetAdUiParent
#define SetAdUiParent SetGdUiParent
#endif
