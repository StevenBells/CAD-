﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlPlotProgress.h"
#include "AdAChar.h"
#include "AcPl.h"
#ifndef AcPlPlotProgress
#define AcPlPlotProgress GcPlPlotProgress
#endif

#ifndef AcPlPlotProgressDialog
#define AcPlPlotProgressDialog GcPlPlotProgressDialog
#endif

#ifndef acplCreatePlotProgressDialog
#define acplCreatePlotProgressDialog gcplCreatePlotProgressDialog
#endif

#ifndef ACPLPLTPRGHELPPROC
#define ACPLPLTPRGHELPPROC GCPLPLTPRGHELPPROC
#endif

