﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlHostAppServices.h"

#ifndef AcPlHostAppServices
#define AcPlHostAppServices GcPlHostAppServices
#endif

#ifndef AcPlSetHostAppServices
#define AcPlSetHostAppServices GcPlSetHostAppServices
#endif

#ifndef AcPlGetHostAppServices
#define AcPlGetHostAppServices GcPlGetHostAppServices
#endif

#ifndef acadInternalServices
#define acadInternalServices gcadInternalServices
#endif

#ifndef AcadPlotInternalServices
#define AcadPlotInternalServices GcadPlotInternalServices
#endif


#ifndef AcPlPlotLogger
#define AcPlPlotLogger GcPlPlotLogger
#endif

