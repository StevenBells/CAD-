﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/embeddedASMEntPE.h"
#include "acdbport.h"
#include "rxobject.h"

#ifndef AcDbEmbeddedASMEntPropsPE
#define AcDbEmbeddedASMEntPropsPE GcDbEmbeddedASMEntPropsPE
#endif
