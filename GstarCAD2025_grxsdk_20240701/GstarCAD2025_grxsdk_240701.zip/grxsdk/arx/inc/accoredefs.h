﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gccoredefs.h"
#include "adesk.h"

#ifndef ACCORE_PORT
#define ACCORE_PORT GCCORE_PORT
#endif

#ifndef ACCORE_DATA_PORT
#define ACCORE_DATA_PORT GCCORE_DATA_PORT
#endif

#ifndef ACCORE_STATIC_DATA_PORT
#define ACCORE_STATIC_DATA_PORT GCCORE_STATIC_DATA_PORT
#endif
