﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlPlotErrorHandler.h"
#include "AcPlObject.h"

#ifndef AcPlSystemInternals
#define AcPlSystemInternals GcPlSystemInternals
#endif

#ifndef AcPlPlotErrorHandler
#define AcPlPlotErrorHandler GcPlPlotErrorHandler
#endif

#ifndef ACPL_ULONG_PTR
#define ACPL_ULONG_PTR GCPL_ULONG_PTR
#endif
