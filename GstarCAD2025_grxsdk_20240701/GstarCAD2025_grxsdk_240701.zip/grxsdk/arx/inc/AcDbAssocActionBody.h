﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocActionBody.h"
#include "AcDbAssocAction.h"
#include "dbeval.h"
#include "AcValue.h"

#ifndef AcDbAssocActionBody
#define AcDbAssocActionBody GcDbAssocActionBody
#endif
