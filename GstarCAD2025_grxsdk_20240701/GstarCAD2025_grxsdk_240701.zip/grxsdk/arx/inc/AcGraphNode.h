﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcGraphNode.h"
#ifndef AcGraphNode
#define AcGraphNode GcGraphNode
#endif

#ifndef AcGraph
#define AcGraph GcGraph
#endif

#ifndef AcImpGraphNode
#define AcImpGraphNode GcImpGraphNode
#endif

