﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gxpnt2d.h"
#include "gept2dar.h"
#include "gepnt2d.h"
#include "gevec2d.h"

#ifndef AcAxPoint2d
#define AcAxPoint2d GcAxPoint2d
#endif

#ifndef AcAxPoint2dArray
#define AcAxPoint2dArray GcAxPoint2dArray
#endif
