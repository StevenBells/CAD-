﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocManager.h"
#include "AcString.h"
#include "AcDbAssocGlobal.h"
#ifndef AcDbAssocManager
#define AcDbAssocManager GcDbAssocManager
#endif

#ifndef AcDbAssocNetworkEvaluationDisabler
#define AcDbAssocNetworkEvaluationDisabler GcDbAssocNetworkEvaluationDisabler
#endif
