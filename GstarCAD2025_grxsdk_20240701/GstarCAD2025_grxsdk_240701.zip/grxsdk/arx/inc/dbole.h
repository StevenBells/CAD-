﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbole.h"
#include "dbmain.h"
#include "dbframe.h"
#include "gepnt3d.h"

#ifndef AcDbOleFrame
#define AcDbOleFrame GcDbOleFrame
#endif

#ifndef AcDbOle2Frame
#define AcDbOle2Frame GcDbOle2Frame
#endif

