﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbmtext.h"
#include "dbmain.h"

#ifndef AcDbMTextFragment
#define AcDbMTextFragment GcDbMTextFragment
#endif

#ifndef AcDbMTextEnum
#define AcDbMTextEnum GcDbMTextEnum
#endif

#ifndef AcDbMText
#define AcDbMText GcDbMText
#endif

#ifndef AcDbText
#define AcDbText GcDbText
#endif

