﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbfilter.h"
#include "dbmain.h"

#ifndef AcDbFilteredBlockIterator
#define AcDbFilteredBlockIterator GcDbFilteredBlockIterator
#endif

#ifndef AcDbFilter
#define AcDbFilter GcDbFilter
#endif
