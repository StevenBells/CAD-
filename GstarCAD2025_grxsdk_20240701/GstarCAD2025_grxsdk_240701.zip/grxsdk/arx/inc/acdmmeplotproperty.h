﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcdmmeplotproperty.h"
#include "acarray.h"

#ifndef AcDMMXMLAttribute
#define AcDMMXMLAttribute GcDMMXMLAttribute
#endif

#ifndef AcDMMXMLAttributeVec
#define AcDMMXMLAttributeVec GcDMMXMLAttributeVec
#endif

#ifndef AcDMMEPlotProperty
#define AcDMMEPlotProperty GcDMMEPlotProperty
#endif

#ifndef AcDMMEPlotPropertyVec
#define AcDMMEPlotPropertyVec GcDMMEPlotPropertyVec
#endif

