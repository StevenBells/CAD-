﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbGeoTypes.h"
#ifndef AcGeoMapType
#define AcGeoMapType GcGeoMapType
#endif

#ifndef AcGeoMapResolution
#define AcGeoMapResolution GcGeoMapResolution
#endif

