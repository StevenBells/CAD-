﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiCoupledGroupCtrl.h"

#ifndef ADUI_DEFAULT_TREE_TO_DETAILS_RATIO
#define ADUI_DEFAULT_TREE_TO_DETAILS_RATIO GDUI_DEFAULT_TREE_TO_DETAILS_RATIO
#endif

#ifndef CAdUiCoupledGroupCtrl
#define CAdUiCoupledGroupCtrl CGdUiCoupledGroupCtrl
#endif

#ifndef CAdUiGroupCtrl
#define CAdUiGroupCtrl CGdUiGroupCtrl
#endif
