﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocArrayModifyActionBody.h"
#include "AcDbAssocArrayActionBody.h"

#ifndef AcDbAssocArrayModifyActionBody
#define AcDbAssocArrayModifyActionBody GcDbAssocArrayModifyActionBody
#endif

#ifndef AcDbVertexRef
#define AcDbVertexRef GcDbVertexRef
#endif
