﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocPathBasedSurfaceActionBody.h"
#include "AcDbAssocEdgeActionParam.h"
#include "AcDbAssocSurfaceActionBody.h"
#include "AcDbAssocVertexActionParam.h"
#ifndef AcDbAssocPathBasedSurfaceActionBody
#define AcDbAssocPathBasedSurfaceActionBody GcDbAssocPathBasedSurfaceActionBody
#endif
