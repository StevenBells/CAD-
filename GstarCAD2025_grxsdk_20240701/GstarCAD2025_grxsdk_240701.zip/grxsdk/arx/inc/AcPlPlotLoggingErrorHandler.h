﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlPlotLoggingErrorHandler.h"

#ifndef AcPlPlotLogger
#define AcPlPlotLogger GcPlPlotLogger
#endif

#ifndef AcPlSystenInternals
#define AcPlSystenInternals GcPlSystenInternals
#endif

#ifndef AcPlPlotLoggingErrorHandler
#define AcPlPlotLoggingErrorHandler GcPlPlotLoggingErrorHandler
#endif
