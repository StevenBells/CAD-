﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbptrar.h"
#include "adesk.h"
#include "assert.h"

#include "acarray.h"

#ifndef AcDbVoidPtrArray
#define AcDbVoidPtrArray GcDbVoidPtrArray
#endif

