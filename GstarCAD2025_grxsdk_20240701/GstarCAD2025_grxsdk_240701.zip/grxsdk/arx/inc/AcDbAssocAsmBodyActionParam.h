﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocAsmBodyActionParam.h"
#include "AcDbAssocEdgeActionParam.h"
#include "AcDbAssocCompoundActionParam.h"

#ifndef AcDbAssocAsmBodyActionParam
#define AcDbAssocAsmBodyActionParam GcDbAssocAsmBodyActionParam
#endif
