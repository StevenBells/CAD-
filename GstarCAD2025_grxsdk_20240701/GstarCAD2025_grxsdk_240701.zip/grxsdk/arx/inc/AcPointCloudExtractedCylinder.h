﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPointCloudExtractedCylinder.h"

#ifndef AcPointCloudExtractedCylinder
#define AcPointCloudExtractedCylinder GcPointCloudExtractedCylinder
#endif

#ifndef AcPointCloudExtractedCylinderImp
#define AcPointCloudExtractedCylinderImp GcPointCloudExtractedCylinderImp
#endif
