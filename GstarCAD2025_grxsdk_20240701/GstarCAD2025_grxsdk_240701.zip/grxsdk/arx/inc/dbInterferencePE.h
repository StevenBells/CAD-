﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "acdb.h"
#include "dbmain.h"
#include "../../inc/dbInterferencePE.h"

#ifndef AcDbInterferencePE
#define AcDbInterferencePE GcDbInterferencePE
#endif

