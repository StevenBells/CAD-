﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "dbgrip.h"
#include "dbmleaderstyle.h"
#include "dbents.h"
#include "../../inc/dbmleader.h"

#ifndef AcDbMLeader
#define AcDbMLeader GcDbMLeader
#endif

#ifndef AcDbMLeaderObjectContextData
#define AcDbMLeaderObjectContextData GcDbMLeaderObjectContextData
#endif
