﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbPointCloudCrop.h"
#ifndef Autodesk
#define Autodesk Gssoft
#endif

#ifndef AcDbPointCloudCrop
#define AcDbPointCloudCrop GcDbPointCloudCrop
#endif

#ifndef AcDbPointCloudDxfHandler
#define AcDbPointCloudDxfHandler GcDbPointCloudDxfHandler
#endif
