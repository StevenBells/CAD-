﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GdGChar.h"

#ifndef AD_UNICODE
#define AD_UNICODE GD_UNICODE
#endif

#ifndef ACHAR
#define ACHAR GCHAR
#endif

#ifndef _ACRX_T
#define _ACRX_T _GCRX_T
#endif

#ifndef ACRX_T
#define ACRX_T GCRX_T
#endif
