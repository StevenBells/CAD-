﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcGiStyleAttributes.h"
#include "AcGiLineAttributes.h"
#include "dbid.h"
#include "dbcolor.h"

#ifndef AcGiStyleAttributes
#define AcGiStyleAttributes GcGiStyleAttributes
#endif
