﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/clipdata.h"
#include "accoredefs.h"
#include "AdAChar.h"

#ifndef acedClipFormatName
#define acedClipFormatName gcedClipFormatName
#endif
