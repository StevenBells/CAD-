﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcGiLineAttrUtils.h"
#include "acdb.h"

#ifndef AcGiLineAttrUtils
#define AcGiLineAttrUtils GcGiLineAttrUtils
#endif

#ifndef acgiLineWeightToIndex
#define acgiLineWeightToIndex gcgiLineWeightToIndex
#endif

#ifndef acgiIndexToLineWeight
#define acgiIndexToLineWeight gcgiIndexToLineWeight
#endif
