﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcgidrawstream.h"

#ifndef AcGiDrawStreamImp
#define AcGiDrawStreamImp GcGiDrawStreamImp
#endif

#ifndef AcGiDrawStream
#define AcGiDrawStream GcGiDrawStream
#endif

