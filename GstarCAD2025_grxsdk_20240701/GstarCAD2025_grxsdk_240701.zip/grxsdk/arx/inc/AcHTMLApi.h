﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcHTMLApi.h"

#ifndef acedAddHTMLPalette
#define acedAddHTMLPalette gcedAddHTMLPalette
#endif

#ifndef acedShowHTMLModalWindow
#define acedShowHTMLModalWindow gcedShowHTMLModalWindow
#endif

#ifndef acedShowHTMLModelessWindow
#define acedShowHTMLModelessWindow gcedShowHTMLModelessWindow
#endif

#ifndef acedShowHTMLModalWindow
#define acedShowHTMLModalWindow gcedShowHTMLModalWindow
#endif

#ifndef acedAddHTMLDocWindow
#define acedAddHTMLDocWindow gcedAddHTMLDocWindow
#endif

#ifndef acedLoadJSScript
#define acedLoadJSScript gcedLoadJSScript
#endif

#ifndef AcApDocWindow
#define AcApDocWindow GcApDocWindow
#endif

