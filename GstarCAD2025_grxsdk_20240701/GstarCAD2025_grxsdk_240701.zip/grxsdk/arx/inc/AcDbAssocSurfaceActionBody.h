﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocSurfaceActionBody.h"
#include "AcDbAssocParamBasedActionBody.h"
#ifndef AcDbAssocSurfaceActionBody
#define AcDbAssocSurfaceActionBody GcDbAssocSurfaceActionBody
#endif
