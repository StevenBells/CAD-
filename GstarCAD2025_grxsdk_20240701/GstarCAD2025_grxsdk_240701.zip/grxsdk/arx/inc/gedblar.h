﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gedblar.h"
#include "adesk.h"
#include "assert.h"
#include "acarray.h"

#ifndef AcArray
#define AcArray GcArray
#endif

#ifndef AcGeDoubleArray
#define AcGeDoubleArray GcGeDoubleArray
#endif

