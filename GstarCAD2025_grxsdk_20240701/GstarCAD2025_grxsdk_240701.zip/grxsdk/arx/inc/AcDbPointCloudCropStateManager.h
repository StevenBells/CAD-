﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbPointCloudCropStateManager.h"

#ifndef AcDbPointCloudCropStateManagerImp
#define AcDbPointCloudCropStateManagerImp GcDbPointCloudCropStateManagerImp
#endif

#ifndef AcDbPointCloudEx
#define AcDbPointCloudEx GcDbPointCloudEx
#endif

#ifndef AcDbPointCloudCropStateManager
#define AcDbPointCloudCropStateManager GcDbPointCloudCropStateManager
#endif
