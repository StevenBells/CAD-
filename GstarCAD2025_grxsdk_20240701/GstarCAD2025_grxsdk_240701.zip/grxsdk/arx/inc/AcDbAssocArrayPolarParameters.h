﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocArrayPolarParameters.h"
#include "AcDbAssocArrayCommonParameters.h"

#ifndef AcDbAssocArrayPolarParameters
#define AcDbAssocArrayPolarParameters GcDbAssocArrayPolarParameters
#endif

#ifndef AcDbImpAssocArrayPolarParameters
#define AcDbImpAssocArrayPolarParameters GcDbImpAssocArrayPolarParameters
#endif
