﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlPrecisionEntry.h"
#include "AcPl.h"
#include "AcPlObject.h"
#ifndef AcPlPrecisionEntry
#define AcPlPrecisionEntry GcPlPrecisionEntry
#endif

