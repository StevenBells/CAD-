﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcuiNavDialog.h"

#ifndef AcUiOpenNoTemplateFlag
#define AcUiOpenNoTemplateFlag GcUiOpenNoTemplateFlag
#endif

#ifndef CAcUiNavDialog
#define CAcUiNavDialog CGcUiNavDialog
#endif

#ifndef acUiOpenNoTemplateNone
#define acUiOpenNoTemplateNone gcUiOpenNoTemplateNone
#endif

#ifndef acUiOpenNoTemplateImperail
#define acUiOpenNoTemplateImperail gcUiOpenNoTemplateImperail
#endif

#ifndef acUiOpenNoTemplateMetric
#define acUiOpenNoTemplateMetric gcUiOpenNoTemplateMetric
#endif

#ifndef CAcUiNavPreviewButton
#define CAcUiNavPreviewButton CGcUiNavPreviewButton
#endif

