﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiPathname.h"
#include "adesk.h"
#include "acbasedefs.h"
#include "aduipathenums.h"
#include "AcString.h"

#ifndef CAdUiPathname
#define CAdUiPathname CGdUiPathname
#endif

#ifndef CAdUiVolumeDescriptor
#define CAdUiVolumeDescriptor CGdUiVolumeDescriptor
#endif
