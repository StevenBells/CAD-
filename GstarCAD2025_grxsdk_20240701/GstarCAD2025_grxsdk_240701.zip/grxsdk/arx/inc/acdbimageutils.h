﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcdbimageutils.h"
#include "acdbport.h"
#ifndef acdbGetPreviewBitmapFromDwg
#define acdbGetPreviewBitmapFromDwg gcdbGetPreviewBitmapFromDwg
#endif
