﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcTcUiToolPaletteGroup.h"
#include "AcTcUiToolPalette.h"

#ifndef CAcTcUiToolPaletteGroup
#define CAcTcUiToolPaletteGroup CGcTcUiToolPaletteGroup
#endif

#ifndef CAcTcUiImpToolPaletteGroup
#define CAcTcUiImpToolPaletteGroup CGcTcUiImpToolPaletteGroup
#endif

#ifndef CAcTcUiImpToolPaletteSet
#define CAcTcUiImpToolPaletteSet CGcTcUiImpToolPaletteSet
#endif

