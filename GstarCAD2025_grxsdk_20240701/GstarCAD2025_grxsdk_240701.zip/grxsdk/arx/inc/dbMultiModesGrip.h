﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbMultiModesGrip.h"
#include "acdb.h"
#include "dbmain.h"
#include "AcString.h"

#ifndef AcDbMultiModesGripPE
#define AcDbMultiModesGripPE GcDbMultiModesGripPE
#endif

