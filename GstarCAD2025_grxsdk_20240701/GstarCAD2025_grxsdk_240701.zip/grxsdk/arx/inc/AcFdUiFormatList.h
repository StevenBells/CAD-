﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcFdUiFormatList.h"
#include "AcFdUi.h"

#ifndef CAcFdUiFormatList
#define CAcFdUiFormatList CGcFdUiFormatList
#endif


#ifndef AcTcUiSystemInternals
#define AcTcUiSystemInternals GcTcUiSystemInternals
#endif

