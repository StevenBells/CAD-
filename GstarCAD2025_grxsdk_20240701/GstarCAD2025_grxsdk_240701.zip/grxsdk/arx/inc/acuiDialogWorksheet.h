﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcuiDialogWorksheet.h"
#include "aduiDialogWorksheet.h"
#ifndef CAcUiDialogWorksheet
#define CAcUiDialogWorksheet CGcUiDialogWorksheet
#endif


