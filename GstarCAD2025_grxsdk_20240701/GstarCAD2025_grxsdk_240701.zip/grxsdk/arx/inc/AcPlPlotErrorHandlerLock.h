﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPlPlotErrorHandlerLock.h"
#include "AdAChar.h"
#include "AcPlObject.h"
#ifndef AcPlPlotErrorHandlerLock
#define AcPlPlotErrorHandlerLock GcPlPlotErrorHandlerLock
#endif

