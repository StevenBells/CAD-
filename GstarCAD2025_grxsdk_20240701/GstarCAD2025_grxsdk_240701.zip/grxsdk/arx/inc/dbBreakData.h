﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbBreakData.h"
#include "dbmain.h"

#ifndef AcDbBreakData
#define AcDbBreakData GcDbBreakData
#endif

#ifndef AcDbBreakPointRef
#define AcDbBreakPointRef GcDbBreakPointRef
#endif

#ifndef acdbGetBreakSubentIndex
#define acdbGetBreakSubentIndex gcdbGetBreakSubentIndex
#endif
