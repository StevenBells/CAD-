﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbPropertyFilterCustomizationPE.h"
#include "acdb.h"
#include "dynprops-AcFilterablePropertyContext.h"

#ifndef AcDbPropertyFilterCustomizationPE
#define AcDbPropertyFilterCustomizationPE GcDbPropertyFilterCustomizationPE
#endif

