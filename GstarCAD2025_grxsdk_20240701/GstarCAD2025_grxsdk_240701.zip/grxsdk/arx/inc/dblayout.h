﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once

#include "dbmain.h"
#include "dbdict.h"
#include "AdAChar.h"
#include "dbplotsettings.h"
#include "../../inc/dblayout.h"

#ifndef Atil
#define Atil Gtil
#endif

#ifndef AcDbLayout
#define AcDbLayout GcDbLayout
#endif

