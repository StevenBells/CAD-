﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/dbproxy.h"
#include "dbmain.h"
#include "dbintar.h"

#ifndef AcDbProxyObject
#define AcDbProxyObject GcDbProxyObject
#endif

#ifndef AcDbProxyEntity
#define AcDbProxyEntity GcDbProxyEntity
#endif

