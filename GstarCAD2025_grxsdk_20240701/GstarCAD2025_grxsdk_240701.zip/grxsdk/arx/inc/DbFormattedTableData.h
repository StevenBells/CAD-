﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/DbFormattedTableData.h"
#include "DbLinkedTableData.h"
#include "DbTableIterator.h"

#ifndef AcGridProperty
#define AcGridProperty GcGridProperty
#endif

#ifndef AcDbFormattedTableData
#define AcDbFormattedTableData GcDbFormattedTableData
#endif
