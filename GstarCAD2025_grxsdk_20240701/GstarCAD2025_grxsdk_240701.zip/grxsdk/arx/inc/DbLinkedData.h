﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "AcValue.h"
#include "DbDataLink.h"
#include "../../inc/DbLinkedData.h"

#ifndef AcDbLinkedData
#define AcDbLinkedData GcDbLinkedData
#endif

#ifndef AcDbDataArray
#define AcDbDataArray GcDbDataArray
#endif

