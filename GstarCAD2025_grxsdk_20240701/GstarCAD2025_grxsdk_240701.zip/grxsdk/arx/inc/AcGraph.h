﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcGraph.h"
#include "AcGraphNode.h"

#ifndef AcGraph
#define AcGraph GcGraph
#endif

#ifndef AcImpGraph
#define AcImpGraph GcImpGraph
#endif

#ifndef AcDbObject
#define AcDbObject GcDbObject
#endif

