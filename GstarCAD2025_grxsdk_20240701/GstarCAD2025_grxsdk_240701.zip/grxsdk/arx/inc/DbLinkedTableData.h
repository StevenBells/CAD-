﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "DbLinkedData.h"
#include "DbTableIterator.h"
#include "AcCell.h"
#include "../../inc/DbLinkedTableData.h"

#ifndef AcDbLinkedTableData
#define AcDbLinkedTableData GcDbLinkedTableData
#endif

