﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiHeaderCtrl.h"

#ifndef CAdUiHeaderCtrl
#define CAdUiHeaderCtrl CGdUiHeaderCtrl
#endif

#ifndef GetAdUiParent
#define GetAdUiParent GetGdUiParent
#endif

#ifndef SetAdUiParent
#define SetAdUiParent SetGdUiParent
#endif

#ifndef OnAdUiMessage
#define OnAdUiMessage OnGdUiMessage
#endif

