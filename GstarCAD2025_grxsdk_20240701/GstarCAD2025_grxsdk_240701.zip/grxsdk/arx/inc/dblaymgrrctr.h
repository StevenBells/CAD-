﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "rxobject.h"
#include "dbid.h"
#include "AdAChar.h"
#include "../../inc/dblaymgrrctr.h"

#ifndef AcDbLayoutManagerReactor
#define AcDbLayoutManagerReactor GcDbLayoutManagerReactor
#endif

