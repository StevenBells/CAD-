﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocIndexPersSubentId.h"
#include "AcDbAssocPersSubentId.h"
#ifndef AcDbAssocIndexPersSubentId
#define AcDbAssocIndexPersSubentId GcDbAssocIndexPersSubentId
#endif

#ifndef AcDbAssocExternalIndexPersSubentId
#define AcDbAssocExternalIndexPersSubentId GcDbAssocExternalIndexPersSubentId
#endif

#ifndef AcDbAssocObjectAndIndexPersSubentId
#define AcDbAssocObjectAndIndexPersSubentId GcDbAssocObjectAndIndexPersSubentId
#endif
