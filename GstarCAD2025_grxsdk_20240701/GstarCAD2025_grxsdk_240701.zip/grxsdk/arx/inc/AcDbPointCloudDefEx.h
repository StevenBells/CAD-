﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "dbmain.h"
#include "../../inc/GcDbPointCloudDefEx.h"
#ifndef AcDbPointCloudDefEx
#define AcDbPointCloudDefEx GcDbPointCloudDefEx
#endif

#ifndef AcDbPointCloudDefReactorEx
#define AcDbPointCloudDefReactorEx GcDbPointCloudDefReactorEx
#endif

#ifndef Autodesk
#define Autodesk Gssoft
#endif
