﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gduiImage.h"
#include "aduiTheme.h"

#ifndef CAdUiImage
#define CAdUiImage CGdUiImage
#endif

#ifndef CAdUiImageResource
#define CAdUiImageResource CGdUiImageResource
#endif
