﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbGeoPositionMarker.h"
#include "dbmain.h"
#include "acdbport.h"
#include "AcString.h"

#ifndef AcDbMText
#define AcDbMText GcDbMText
#endif

#ifndef AcDbGeoPositionMarker
#define AcDbGeoPositionMarker GcDbGeoPositionMarker
#endif
