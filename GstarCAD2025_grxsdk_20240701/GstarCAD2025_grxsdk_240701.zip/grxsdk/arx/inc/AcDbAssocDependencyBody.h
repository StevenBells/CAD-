﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocDependencyBody.h"
#include "AcDbAssocDependency.h"

#ifndef AcDbAssocDependencyBody
#define AcDbAssocDependencyBody GcDbAssocDependencyBody
#endif
