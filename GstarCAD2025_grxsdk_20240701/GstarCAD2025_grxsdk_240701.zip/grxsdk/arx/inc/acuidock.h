﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gcuidock.h"
#ifndef CAcUiDockFrame
#define CAcUiDockFrame CGcUiDockFrame
#endif

#ifndef CAcUiDockControlBar
#define CAcUiDockControlBar CGcUiDockControlBar
#endif

#ifndef CAcUiPaletteSetDockFrame
#define CAcUiPaletteSetDockFrame CGcUiPaletteSetDockFrame
#endif

#ifndef OnACADKeepFocus
#define OnACADKeepFocus OnGCADKeepFocus
#endif
