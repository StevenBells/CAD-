﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDbAssocEdgePersSubentId.h"
#include "acarray.h"
#include "dbsubeid.h"
#include "AcDbAssocPersSubentId.h"

#ifndef AcDbAssocEdgePersSubentId
#define AcDbAssocEdgePersSubentId GcDbAssocEdgePersSubentId
#endif
