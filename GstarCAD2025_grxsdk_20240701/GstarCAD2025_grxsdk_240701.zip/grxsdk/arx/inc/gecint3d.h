﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/gecint3d.h"
#include "adesk.h"
#include "geent3d.h"
#include "geponc3d.h"
#include "geintrvl.h"

#ifndef AcGeCurve3d
#define AcGeCurve3d GcGeCurve3d
#endif

#ifndef AcGeXConfig
#define AcGeXConfig GcGeXConfig
#endif

#ifndef AcGeCurveCurveInt3d
#define AcGeCurveCurveInt3d GcGeCurveCurveInt3d
#endif

