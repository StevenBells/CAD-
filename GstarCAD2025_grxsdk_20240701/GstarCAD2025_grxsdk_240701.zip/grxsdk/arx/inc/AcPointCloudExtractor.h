﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcPointCloudExtractor.h"
#include "AcDbPointCloudEx.h"
#include "AcPointCloudExtractProfileCurve.h"
#ifndef AcPointCloudExtractor
#define AcPointCloudExtractor GcPointCloudExtractor
#endif

