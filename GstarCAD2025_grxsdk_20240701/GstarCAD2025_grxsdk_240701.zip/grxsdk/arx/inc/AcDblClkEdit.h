﻿/////////////////////////////////////////////////////////////////////////////////////////
//
// Please refer to "COPYRIGHT.md" for the relevant copyright statement of this software.
//
/////////////////////////////////////////////////////////////////////////////////////////
//
#pragma once
#include "../../inc/GcDblClkEdit.h"
#include "acdb.h"
#include "dbmain.h"
#ifndef AcDbDoubleClickEdit
#define AcDbDoubleClickEdit GcDbDoubleClickEdit
#endif
